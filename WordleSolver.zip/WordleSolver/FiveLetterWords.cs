﻿namespace WordleSolver
{
    public class FiveLetterWords
    {
        public string? Word { get; set; }


    }
}
