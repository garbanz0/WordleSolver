﻿public enum CharacterUsedStateType : int
{
    Init = 0,
    Success = 1,
    Failed = 2
}

