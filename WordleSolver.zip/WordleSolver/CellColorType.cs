﻿public enum CellColorType : int
{
    DarkGray = 0,
    Gold = 1,
    Green = 2
}

